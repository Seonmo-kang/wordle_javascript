
var secretWord = "";
var wordLength = 5;
var maxAttempt = 6;
var gameOver = false;

var isWordBoolean;

var arr = new Array();  // correct, absent, present array


var row = 0;
var col = 0;

window.onload = function(){
    initialize();
    typeKeyboard();
    game();
}

function initialize() {
    // create Tile
    //<span id="0-0" class="tile"> p </span>
    for(let r=0;r<maxAttempt;r++){
        for(let c=0;c<wordLength;c++){
            let tile = document.createElement("span")
            tile.id = r.toString() + "-" + c.toString();
            tile.classList.add("tile");
            tile.innerText = '';
            document.getElementById("attempt").appendChild(tile);
        }
    }
    fetch("https://wordsapiv1.p.rapidapi.com/words/?random=true&lettersMin=5&lettersMax=5", {
	"method": "GET",
	"headers": {
		"x-rapidapi-host": "wordsapiv1.p.rapidapi.com",
		"x-rapidapi-key": "${WORDS_API_KEY}"
	}
    })
    .then(response => {
        console.log(response);
        return response.json();
    })
    .then((res) =>{
        secretWord = res.word;
        console.log("secretWord : "+secretWord);
    })
    .catch(err => {
        console.error(err);
    });
}
function game() {
    document.addEventListener("keyup",(e)=>{
        
        if(gameOver){
            alert('you win!');
            return ;
        }
        console.log(e.code);
        // alert(e.code+" key :"+e.key);
        //e.g. e.code = keyA, e.key = A or a.
        if("KeyA" <= e.code && e.code <= "KeyZ"){
            if(col < wordLength){
                let currentTile = document.getElementById( row.toString() +'-'+ col.toString() );
                if(currentTile.innerText == ""){
                    currentTile.innerText = e.code[3];
                    col += 1;
                }
            }
            
        }
        else if( e.code == "Backspace" ){
            typeBacksapce();
        }
        else if( e.code == "Enter"){
            if(col==5){
                isWord();
            }else{
                return;
            }
        }
        loseGame();

    })
}

function typeKeyboard(){
    const keys = document.querySelectorAll(".row button");
    for(let key of keys){
        key.onclick = ({target}) =>{

            let currentTile = document.getElementById( row.toString() +'-'+ col.toString() );
            const data = target.getAttribute("data-key");
            console.log("data"+data);

            if(col<wordLength && data!="Enter" && data!="Backspace"){
                    currentTile.innerText = data;
                    console.log(data);
                    col+=1;
            }else if(data=="Enter"){
                isWord();
            }else if(data=="Backspace"){
                typeBacksapce();
            }
        }
    }
}
/* Enter function */
function typeEnter(){
    let correct=0;
    let present =0;
    let absent =0;

    //Compare words with secret word
    for(let i=0; i< wordLength; i++){

        let currentTile = document.getElementById( row.toString() +'-'+ i.toString() );
        let letter = currentTile.innerText;
        console.log(letter);
        const keyButtons = document.querySelector(`[data-key=${letter}]`);
        let letter_lowercase = letter.toLowerCase();
        

        if( secretWord[i] == letter_lowercase){
            currentTile.classList.add("correct");
            keyButtons.style = "background-color: green";
            correct+=1;
            
        }else if(secretWord.includes(letter_lowercase)){
            currentTile.classList.add("present");
            keyButtons.style = "background-color: orange";
            present+=1;
        }else{
            currentTile.classList.add("absent");
            keyButtons.style = "background-color: brown";
            absent+=1;
        }
        
         let dict = { "correct": correct, "present": present, "absent": absent };
         arr[row] = dict;
    }
        if(correct==5){
            gameOver=true
            result();
        }

        row += 1;
        col = 0;
}
/* Backspace function */
function typeBacksapce() {
    if( 0 < col && col <= wordLength){
        col -= 1;
    }
    let currentTile = document.getElementById( row.toString() +'-'+ col.toString() );
    currentTile.innerText = '';
}

function loseGame() {
    if(!gameOver && row == maxAttempt){
        document.getElementById('word').innerText = secretWord;
        result();
        alert(`Real word was ${secretWord}`);
    }
}
function result(){
    let row_num=0;
    let dataTable = document.getElementById("data-row");
    for(let data of arr){
        row_num+=1;
        let table_row = document.createElement("tr");
        table_row.id = row_num;
        table_row.innerHTML = `<td>${row_num}</td> 
                        <td>${data["absent"]}</td>
                        <td>${data["present"]}</td>
                        <td>${data["correct"]}</td>`;
        dataTable.appendChild(table_row);
    }
    if(row_num!=6){
        for(let i=row_num; i<6; i++){
            row_num+=1;
            let table_row = document.createElement("tr");
            table_row.id = row_num;
            table_row.innerHTML = `<td>${row_num}</td> 
                            <td>0</td>
                            <td>0</td>
                            <td>0</td>`;
            dataTable.appendChild(table_row);
        }
    }
    var overlay = document.getElementById("overlay");
    overlay.style.display = "flex";

}

// get word existed from api.
function isWord(){
    var word='';
    for(let i=0;i<wordLength; i++){
        let currentTile= document.getElementById(row.toString()+'-'+i.toString());
        word+= currentTile.innerText.toLowerCase();
    }
    // fetch function. get word existed or not
    fetch(`https://wordsapiv1.p.rapidapi.com/words/${word}`, {
        "method": "GET",
        "headers": {
            "x-rapidapi-host": "wordsapiv1.p.rapidapi.com",
            "x-rapidapi-key": "${WORDS_API_KEY}"
        }
    })
    .then(response => {
        console.log(response);
        console.log("response : "+response.ok); // word is wrong then response.ok is false 
        if(!response.ok){
            alert("That word does not exist.");
            console.log("isWordBoolean is changed to false");
        }else{
            typeEnter();
            console.log("isWordBoolean is changed to true");
        }
    })
    .catch(err => {
        console.error(err);
    });
}